Import-Module WebAdministration
$logPath = 'C:\iislog'
$siteName = "ContainerizationDemo"

Get-ItemProperty "IIS:\Sites\$siteName" -name logFile

Set-ItemProperty "IIS:\Sites\$siteName" -name logFile -value @{directory=$logPath}
Set-ItemProperty "IIS:\Sites\$siteName" -name logFile -value @{period='MaxSize'}
Set-ItemProperty "IIS:\Sites\$siteName" -name logFile -value @{truncateSize='4294967295'}

$site = Get-Item IIS:\Sites\$siteName
$id = $site.id
$logBase = "\u_extend1.log"
$logfile = $logPath + "\W3SVC" + $id  + $logBase

Start-Service W3SVC

Invoke-WebRequest http://localhost:8081 -UseBasicParsing -OutFile tmpRequest.log
Remove-Item tmpRequest.log
netsh http flush logbuffer
Get-Content -path $logfile -Tail 1 -Wait